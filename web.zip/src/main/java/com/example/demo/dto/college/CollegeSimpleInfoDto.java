package com.example.demo.dto.college;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CollegeSimpleInfoDto {

    private String collegeName;
    private String address;
}
