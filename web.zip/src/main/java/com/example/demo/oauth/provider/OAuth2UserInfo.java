package com.example.demo.oauth.provider;

public interface OAuth2UserInfo {
    String getPhonNumber();
    String getName();
}
