package com.example.demo.domain.value;

public enum EnrollStatus {
    등록, 미_등록
}
