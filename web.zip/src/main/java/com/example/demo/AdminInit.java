//package com.example.demo;
//
//import com.example.demo.domain.entity.Admin;
//import com.example.demo.domain.entity.User;
//import com.example.demo.domain.value.Gender;
//import com.example.demo.domain.value.Role;
//import com.example.demo.repository.AdminRepository;
//import com.example.demo.service.user.UserService;
//import lombok.RequiredArgsConstructor;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.stereotype.Component;
//
//import javax.annotation.PostConstruct;
//
//
///**
// * 초기 admin 데이터 저장 클래스, DI(의존 관계) 주입 후 바로 실행 될 메서드 정의
// * 0508 수정
// */
//
//@Component
//@RequiredArgsConstructor
//public class AdminInit {
//
//    private final UserService userService;
//    private final AdminRepository adminRepository;
//    private final BCryptPasswordEncoder bCryptPasswordEncoder;
//
//    @PostConstruct
//    public void init() {
//        User user = User.createUser()
//                .id("1")
//                .phonNumber("admin")
//                .password(bCryptPasswordEncoder.encode("admin"))
//                .name("admin")
//                .age(0)
//                .role(Role.ROLE_ADMIN)  // 역할을 어드민으로 넣어주고
//                .gender(Gender.MALE)
//                .car_number("admin")
//                .build();
//
//        User savedUser = userService.createUser(user);
//        Admin admin = Admin.createAdmin()
//                .id(savedUser.getUser_id())
//                .name(savedUser.getName())
//                .password(savedUser.getPassword())
//                .build();
//        adminRepository.save(admin);
//
//    }
//
//}
//
//
//
